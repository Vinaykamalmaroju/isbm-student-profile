ISBM University student profile website
========================================

1. Open GitHub.com and sign in (create a free account if needed).
2. Create a new repository. Name it: isbm-student-profile
3. Set it to Public, then click Create repository.
4. Choose Add file > Upload files.
5. Upload index.html from this folder. If you have an official logo image you are authorized to use, upload it as college-logo.png.
6. Click Commit changes.
7. Open the repository's Settings > Pages.
8. Under Build and deployment, choose "Deploy from a branch".
9. Choose branch "main" and folder "/ (root)", then Save.
10. Wait a few minutes. GitHub Pages will show a public website address in Settings > Pages.
11. Open that address on your phone to confirm the page loads.
12. Use the public website address to generate a QR code. The QR should contain the URL, not the student details text.

Logo:
- No official logo was supplied with this project.
- If you have a logo image you are authorized to use, upload it with the exact filename college-logo.png.

Privacy and verification:
- The repository and website must be public for anyone scanning the QR to open the page.
- The page is a personal profile and does not verify the student's enrolment with the university.
- Avoid adding personal data beyond what you intend to make public.
